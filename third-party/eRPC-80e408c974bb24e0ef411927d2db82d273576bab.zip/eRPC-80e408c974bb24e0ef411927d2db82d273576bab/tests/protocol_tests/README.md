Tests for datapath and management protocol.
