# xia-cerberus
ifconfig enp4s0f0 192.168.1.230
ifconfig enp4s0f1 192.168.1.231
ifconfig enp130s0f0 192.168.1.232
ifconfig enp130s0f1 192.168.1.233
