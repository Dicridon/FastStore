# fawn-pluto0
ifconfig enp4s0f0 192.168.1.200
ifconfig enp4s0f1 192.168.1.201
ifconfig enp132s0f0 192.168.1.202
ifconfig enp132s0f1 192.168.1.203
