# xia-wimpy
ifconfig enp4s0f0 192.168.1.220
ifconfig enp4s0f1 192.168.1.221
ifconfig enp132s0f0 192.168.1.222
ifconfig enp132s0f1 192.168.1.223
