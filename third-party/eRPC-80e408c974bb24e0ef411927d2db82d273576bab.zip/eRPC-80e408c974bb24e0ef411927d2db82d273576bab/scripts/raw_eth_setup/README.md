Scripts to bring up Mellanox Ethernet links on FAWN cluster.
