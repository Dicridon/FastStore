export opcode=ib_write_bw
