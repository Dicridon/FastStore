#!/usr/bin/env bash
source $(dirname $0)/opcode.sh
killall $opcode
