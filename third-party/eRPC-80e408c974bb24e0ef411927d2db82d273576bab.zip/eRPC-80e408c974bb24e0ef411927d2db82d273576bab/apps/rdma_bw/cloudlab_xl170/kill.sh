#!/usr/bin/env bash
killall ib_write_bw
