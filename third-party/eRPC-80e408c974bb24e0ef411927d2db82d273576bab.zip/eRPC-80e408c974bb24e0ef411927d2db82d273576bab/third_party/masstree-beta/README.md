From https://github.com/anujkaliaiitd/masstree-beta.

Do not use bootstrap.sh. Use cmake.

