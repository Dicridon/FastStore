#! /bin/sh -e

autoreconf -i

echo "Now, run ./configure."
