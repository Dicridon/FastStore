#define ERPC_MAGIC_WRID_FOR_FAST_RECV 3185
#define ERPC_MODDED_PROBE_WRID 3186
#define ERPC_MODDED_PROBE_RET 3187

#define MODDED_PRINTF(...) do { fprintf(stderr , __VA_ARGS__); } while(0)
//#define DEBUG_PRINT(...) do{} while (0)
