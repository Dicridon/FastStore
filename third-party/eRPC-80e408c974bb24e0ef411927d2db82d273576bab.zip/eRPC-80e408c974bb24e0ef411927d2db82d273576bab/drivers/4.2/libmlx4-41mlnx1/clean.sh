rm -rf \
  src/*.o \
  src/*lo \
  configure \
  Makefile.in \
  autom4te.cache \
  aclocal.m4 \
  stamp-h.in \
  config.h.in \
  config.log \
  config.h \
  src/.libs \
  src/.deps \
  libmlx4.spec \
  Makefile \
  config.status \
  stamp-h1 \
  libtool \
